package com.thomas.ads.common;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdvertisementTest {

    @Test
    void testSetAndGetId() {
        Advertisement ad = new Advertisement("1", "Ad Content", "Advertiser1", true);
        ad.setId("2");
        assertEquals("2", ad.getId());
    }

    @Test
    void testSetAndGetContent() {
        Advertisement ad = new Advertisement("1", "Ad Content", "Advertiser1", true);
        ad.setContent("New Content");
        assertEquals("New Content", ad.getContent());
    }

}
