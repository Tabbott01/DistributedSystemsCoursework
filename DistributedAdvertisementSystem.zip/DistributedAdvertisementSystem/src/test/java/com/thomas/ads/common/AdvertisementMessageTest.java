package com.thomas.ads.common;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdvertisementMessageTest {

    @Test
    void testSerializationAndDeserialization() throws Exception {
        AdvertisementMessage original = new AdvertisementMessage("1", "Test Ad", true);
        String json = original.toJson();
        AdvertisementMessage result = AdvertisementMessage.fromJson(json);

        assertEquals(original.getId(), result.getId());
        assertEquals(original.getContent(), result.getContent());
        assertTrue(result.isActive());
    }
}
