package com.thomas.ads.server;

import com.thomas.ads.common.Advertisement;
import com.thomas.ads.common.IAdvertisementManagement;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.ConcurrentHashMap;

// Implementation of the IAdvertisementManagement interface
public class AdvertisementManagementImpl extends UnicastRemoteObject implements IAdvertisementManagement {
    
    // // Thread-safe collection to store advertisements.
    private ConcurrentHashMap<String, Advertisement> advertisements;
    
    // Constructs an AdvertisementManagementImpl instance.
    protected AdvertisementManagementImpl() throws RemoteException {
        super(); // Call UnicastRemoteObject constructor to create a remotely accessible object.
        advertisements = new ConcurrentHashMap<>();
    }
    
    // Submits a new advertisement to the system.
    @Override
    public void submitAdvertisement(Advertisement ad) throws RemoteException {
        advertisements.put(ad.getId(), ad); // Store the advertisement using its ID as the key.
        System.out.println("Advertisement submitted: " + ad.getId() + " | Content: " + ad.getContent());
    }
    
    // Edits an existing advertisement.
    @Override
    public void editAdvertisement(String adId, Advertisement newAd) throws RemoteException {
        advertisements.replace(adId, newAd); // Replace the existing advertisement with the new one.
        System.out.println("Advertisement edited: " + adId + " | New Content: " + newAd.getContent());
    }
    
    // Archives an advertisement by setting its active status to false.
    @Override
    public void archiveAdvertisement(String adId) throws RemoteException {
        Advertisement adToArchive = advertisements.get(adId); // Retrieve the advertisement to be archived.
        if (adToArchive != null) {
            adToArchive.setActive(false); // Set the advertisement's active status to false.
            System.out.println("Advertisement archived: " + adId);
        }
    }
}
