package com.thomas.ads.common;
import java.rmi.Remote;
import java.rmi.RemoteException;

// Defines the remote interface for managing advertisements.

public interface IAdvertisementManagement extends Remote {
    // Submits a new advertisement to be scheduled and displayed in the magazine
    void submitAdvertisement(Advertisement ad) throws RemoteException;
    // Edits an existing advertisement based on the provided updated details.
    void editAdvertisement(String adId, Advertisement newAd) throws RemoteException;
    // Archives an advertisement that is no longer active or needed.
    void archiveAdvertisement(String adId) throws RemoteException;
}
