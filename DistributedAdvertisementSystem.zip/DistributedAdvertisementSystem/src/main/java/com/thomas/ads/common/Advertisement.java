package com.thomas.ads.common;
import java.io.Serializable;

// Represents an advertisement in the magazine's publication system.

public class Advertisement implements Serializable {
    private static final long serialVersionUID = 1L; // Standard serialVersionUID for Serializable classes.
    private String id; // Unique identifier for the advertisement.
    private String content; // Description or content of the advertisement
    private String advertiserId; // Link to the Advertiser
    private boolean isActive; // Is the advertisement currently active

    // Constructs a new Advertisement instance.
    public Advertisement(String id, String content, String advertiserId, boolean isActive) {
        this.id = id;
        this.content = content;
        this.advertiserId = advertiserId;
        this.isActive = isActive;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAdvertiserId() {
        return advertiserId;
    }

    public void setAdvertiserId(String advertiserId) {
        this.advertiserId = advertiserId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}
