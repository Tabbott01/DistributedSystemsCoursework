package com.thomas.ads.client;

import com.thomas.ads.common.Advertisement;
import com.thomas.ads.common.IAdvertisementManagement;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

// Client class for interacting with the remote advertisement management service.
public class AdvertisementClient {
    private IAdvertisementManagement adManager;
    
    // Constructs an AdvertisementClient that connects to a remote server.
    public AdvertisementClient(String host) {
        try {
            // Locate the RMI registry on the given host
            Registry registry = LocateRegistry.getRegistry(host);
            // Lookup the remote object "AdvertisementManagement" in the registry
            adManager = (IAdvertisementManagement) registry.lookup("AdvertisementManagement");
            System.out.println("Connected to server");
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }

    // Submits an advertisement to the remote advertisement management system.
    public void submitAdvertisement(Advertisement ad) {
        try {
            adManager.submitAdvertisement(ad);
            System.out.println("Advertisement submitted");
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }

    // Main method to create an AdvertisementClient and use it to submit an advertisement.
    public static void main(String[] args) {
        try {
            // Determine the host from command line arguments; defaults to localhost if not specified.
            String host = (args.length < 1) ? null : args[0];
            AdvertisementClient client = new AdvertisementClient(host);

            // Create an advertisement and submit it
            Advertisement ad = new Advertisement("1", "Buy our products!", "001", true);
            client.submitAdvertisement(ad);
            // Additional operations could be added here to interact with the remote system.

        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
