package com.thomas.ads.messaging;

import com.thomas.ads.common.AdvertisementMessage;

public class ProducerTestDriver {
    // The main method that executes the test by sending an advertisement message.
    public static void main(String[] args) {
        AdvertisementProducer producer = new AdvertisementProducer();
        AdvertisementMessage adMessage = new AdvertisementMessage("1", "Buy our new product!", true);
        producer.send(adMessage);
    }
}
