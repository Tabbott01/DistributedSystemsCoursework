package com.thomas.ads.messaging;

import com.rabbitmq.client.*;
import com.thomas.ads.common.AdvertisementMessage;

// Consumes messages from a RabbitMQ queue dedicated to advertisements.
public class AdvertisementConsumer {
    private final static String QUEUE_NAME = "ads_queue";

    // Starts the message consumption process from the specified RabbitMQ queue.
    public void receive() {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");  // Change this if your RabbitMQ server isn't running locally
        try {
            // Establish a connection to the RabbitMQ server.
            Connection connection = factory.newConnection();
            // Create a channel on this connection.
            Channel channel = connection.createChannel();
            
             // Declare a queue to ensure it exists before attempting to consume messages from it.
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
            System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
            
            // Define the behavior when a message is delivered.
            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String message = new String(delivery.getBody(), "UTF-8");
                System.out.println(" [x] Received '" + message + "'");
                
                // Deserialize the JSON back into an AdvertisementMessage object.
                AdvertisementMessage adMessage = AdvertisementMessage.fromJson(message);
                // Process the received message.
                processMessage(adMessage);
            };
            // Start consuming messages from the queue without auto-acknowledging messages.
            channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> {});
        } catch (Exception e) {
            System.err.println("Failed to set up the consumer: " + e.toString());
            e.printStackTrace();
        }
    }

    private void processMessage(AdvertisementMessage message) {
        // Process the message as needed
        System.out.println("Processing message: " + message.getContent());
    }
}
