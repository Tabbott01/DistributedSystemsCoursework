package com.thomas.ads.messaging;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.thomas.ads.common.AdvertisementMessage;

// Produces and sends messages to a RabbitMQ queue.
public class AdvertisementProducer {
    private final static String QUEUE_NAME = "ads_queue";

    // Sends an advertisement message to the RabbitMQ queue.
    public void send(AdvertisementMessage message) {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {
            
            // Declare the queue where messages will be published. Ensures the queue exists before sending.
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
            // Convert the AdvertisementMessage object to a JSON string.
            String jsonMessage = message.toJson();
            // Publish the message to the queue with the specified queue name.
            channel.basicPublish("", QUEUE_NAME, null, jsonMessage.getBytes());
            System.out.println(" [x] Sent '" + jsonMessage + "'");
            
        } catch (Exception e) {
            // Log and handle exceptions related to connection failures, channel errors, or serialization issues.
            System.err.println("Failed to send message: " + e.toString());
            e.printStackTrace();
        }
    }
}
