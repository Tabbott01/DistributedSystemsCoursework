package com.thomas.ads.messaging;

public class ConsumerTestDriver {
    // The main method that starts the consumer to receive messages.
    public static void main(String[] args) {
        AdvertisementConsumer consumer = new AdvertisementConsumer();
        consumer.receive();
    }
}
