package com.thomas.ads.server;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

// The server application for the advertisement management system.
public class ServerApp {
    public static void main(String[] args) {
        try {
            // Create an instance of the remote object
            AdvertisementManagementImpl remoteAdManager = new AdvertisementManagementImpl();
            
            // Create the RMI registry on a specific port
            Registry registry = LocateRegistry.createRegistry(1099); // Default RMI port
            
            // Bind the remote object's stub in the registry
            registry.rebind("AdvertisementManagement", remoteAdManager);
            
            System.out.println("Server is ready...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
