package com.thomas.ads.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

// Represents a message format for advertisements to be used in message queuing with RabbitMQ.

public class AdvertisementMessage {
    private String id; // Unique identifier for the advertisement.
    private String content; // Description or content of the advertisement
    private boolean isActive; // Is the advertisement currently active

    // Default constructor for use in serialization and deserialization.
    public AdvertisementMessage() {}

    // Constructs a new AdvertisementMessage with specified details.
    public AdvertisementMessage(String id, String content, boolean isActive) {
        this.id = id;
        this.content = content;
        this.isActive = isActive;
    }

    // Standard getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    // Serializes this AdvertisementMessage object to a JSON string
    public String toJson() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(this);
    }

    // Deserializes a JSON string to an AdvertisementMessage object.
    public static AdvertisementMessage fromJson(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, AdvertisementMessage.class);
    }
}
